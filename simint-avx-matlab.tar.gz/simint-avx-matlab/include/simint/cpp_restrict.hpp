#pragma once


// Most compilers should support the __restrict__ syntax
// But this file is left as a placeholder in case they don't

#define restrict __restrict__

