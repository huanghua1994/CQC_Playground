#pragma once

/*! The maximum value of L for which we have precomputed a
*  part of the normalization
*/
#define SHELL_PRIM_NORMFAC_MAXL 20

