#pragma once

#ifdef __cplusplus
extern "C" {
#endif


#include "simint/vectorization/vectorization.h"


#ifdef __cplusplus
}
#endif

