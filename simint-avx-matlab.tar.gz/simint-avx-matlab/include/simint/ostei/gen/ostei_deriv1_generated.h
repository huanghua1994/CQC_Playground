#pragma once



#include "simint/ostei/ostei.h"
#include "simint/ostei/ostei_general.h"
#include "simint/ostei/gen/vrr_generated.h"
#include "simint/ostei/gen/hrr_generated.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

